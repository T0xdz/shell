<b><color> </color></b><br>
Check  Mailling ..<br>
<form method="post">
<input type="text" name="email" value="<?php print $_POST['email']?>"required >
<input type="submit" value="Send test >>">
</form>
<br>
<?php
if (!empty($_POST['email'])){
$xx = rand();
mail($_POST['email'],"Result Report Test - ".$xx,"WORKING !");
print "<b>send an report to [".$_POST['email']."] - $xx</b>"; 
}
?>

 <?php
$to      = 'omarboum18@gmail.com';
$subject = 'the subject';
$message = 'hello this is test message';
$headers = 'From: webmaster@example.com' . "\r\n" .
    'Reply-To: webmaster@example.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

$send = mail($to, $subject, $message, $headers);

if($send)
    echo "<h1>Done send mail ..!</h1>";
    else
        echo "<h1>Error send mail ..!</h1>";
?>   
